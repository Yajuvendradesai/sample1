package com.sample.test.tdg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringJoiner;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

/**
 * Test Data Generator - Main Application
 *
 */
public class App {

    private static boolean featureFileEnabled = true;
    private static final String EXCEL_FILE_NAME = featureFileEnabled ? "DTDG_feature.xlsm" : "DTDG.xlsm";
    private static final String SHEET_NAME = "DTDG_AC";


    public static void main(String[] args) throws IOException {
        // Configure FileName and SheetName
        String excelFileName = App.EXCEL_FILE_NAME;
        String sheetName = App.SHEET_NAME;

        MultiValueMap<String, Map<String, String>> dataMap = new LinkedMultiValueMap<>();
        try (FileInputStream inputStream = new FileInputStream(new ClassPathResource(excelFileName).getFile())) {
            // Read TestData Table
            dataMap = readTableFromExcel(inputStream, sheetName);
        }
        List<String> collect = dataMap.keySet().stream().collect(Collectors.toList());
        List<String> feature = new ArrayList<>();
        for (String key : collect) {
            if (featureFileEnabled) {
                feature.add(getFeatureMap(dataMap, key));
            } else {

            getIdentitiesAndCreateJson(dataMap, key);
            }

        }
        if (featureFileEnabled) {
            generateFeatureFile(feature);
        }

        System.out.println("File generated Successfully!");

    }

    /**
     * @param feature
     */
    public static void generateFeatureFile(List<String> feature) {
        String sdAtt = formatString(feature, "@");
        VelocityContext context = new VelocityContext();
        context.put("feature", sdAtt);
        VelocityEngine velocityEngine = new VelocityEngine();
        velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        velocityEngine.init();
        Template t = velocityEngine.getTemplate(Constants.ResourcePath.FEATURE_TEMPLATE_PATH);
        StringWriter writer = new StringWriter();
        File jsonFile = new File(
                Constants.ResourcePath.GENERATED_FEATURE_PATH + "featureFile" + ".feature");
            try (FileWriter fw = new FileWriter(jsonFile)) {

                t.merge(context, writer);
                fw.write(writer.toString()); //
            } catch (IOException e) {
                e.printStackTrace();
            } //
    }

    /**
     * This method reads the Identities from the data map and Creates the
     * corresponding JSONs.
     * 
     * @param dataMap
     * @param key
     */
    private static String getFeatureMap(MultiValueMap<String, Map<String, String>> dataMap, String key) {

        String scenario = null;
        Optional<Map<String, String>> mapSC = dataMap.get(key).stream().filter(k -> k.get("Scenario") != null)
                .findFirst();
        if (mapSC.isPresent()) {
            scenario = mapSC.get().get("Scenario").toString();
        }
        String testCaseID = null;
        Optional<Map<String, String>> mapTC = dataMap.get(key).stream().filter(k -> k.get("TestCaseID") != null)
                .findFirst();
        if (mapTC.isPresent()) {
            testCaseID = mapTC.get().get("TestCaseID").toString();
        }
        String pid = dataMap.get(key).get(0).get("pid");

        if (StringUtils.isNoneBlank(scenario, testCaseID)) {
            return formatString(Arrays.asList(key, scenario, testCaseID, pid), "#");
        }
        return null;

    }

   

    

    /**
     * This method reads the Identities from the data map and Creates the
     * corresponding JSONs.
     * 
     * @param dataMap
     * @param key
     */
    private static void getIdentitiesAndCreateJson(MultiValueMap<String, Map<String, String>> dataMap, String key) {
        MapLookup mapLookup = new MapLookupImpl();
        VelocityContext context = new VelocityContext();
        List<String> allBgSetsTemp = new ArrayList<>();
        List<String> allBgSets = new ArrayList<>();
        List<String> allRefTemp = new ArrayList<>();
        List<String> allRef = new ArrayList<>();
        VelocityEngine velocityEngine = new VelocityEngine();
        velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        velocityEngine.init();
        Template t = velocityEngine.getTemplate(Constants.ResourcePath.IDENTITY_TEMPLATE_PATH);
        boolean bgSetExists = true;
        List<Map<String, String>> list = dataMap.get(key);
        for (Map<String, String> map : list) {
            // Fetch b For Identity
            if (Constants.TemplateType.IDENTITY.equals(map.get(Constants.TEMPLATE))) {
                int x = 0;
                bgSetExists = true;
                do {
                    String attrRegex = Constants.Regex.B_SETS + x + ".*attr.*";
                    String idRegex = Constants.Regex.B_SETS + x + ".*int.*";
                    String idRegex2 = Constants.Regex.B_SETS + x + ".*purpose.*";
                    String excelSetsAttr = formatString(mapLookup.lookup(attrRegex, map), "$", 2, "|");
                    String excelSetsIdentifier = formatString(mapLookup.lookup(idRegex + "|" + idRegex2, map),
                            ":");
                    if (!StringUtils.isAnyEmpty(excelSetsAttr, excelSetsIdentifier)) {
                        allBgSetsTemp.add(excelSetsAttr + "#" + excelSetsIdentifier);
                    } else {
                        bgSetExists = false;
                        allBgSets.add(formatString(allBgSetsTemp, "@@"));
                        allBgSetsTemp.clear();
                    }
                    x++;
                } while (bgSetExists);

                // Fetch References For Identity
                int y = 0;
                boolean referencesExist = true;
                do {
                    String attrRegex = "references_" + y + ".*";
                    String references = formatString(mapLookup.lookup(attrRegex, map), ":");
                    if (!StringUtils.isAnyEmpty(references)) {
                        allRefTemp.add(references);
                    } else {
                        referencesExist = false;
                        allRef.add(formatString(allRefTemp, "@@"));
                        allRefTemp.clear();
                    }
                    y++;
                } while (referencesExist);
            }
        }
        int index = 0;
        // Set the retrieved values in VelocityContext. These values will be merged with
        // template
        for (Map<String, String> map : list) {
            if (Constants.TemplateType.IDENTITY.equals(map.get(Constants.TEMPLATE))) {
                context.put(Constants.PID, map.get(Constants.PID));
                context.put(Constants.SOURCE, map.get(Constants.SOURCE));
                context.put(Constants.IDENTITY_TYPE, map.get(Constants.IDENTITY_TYPE));
                context.put(Constants.INTERFACE_ID, map.get(Constants.INTERFACE_ID));
                context.put(Constants.CONTAINING_PID, map.get(Constants.CONTAINING_PID));
                context.put("allReferences", allRef.get(index));
                context.put("allBSets", allBgSets.get(index));

                StringWriter writer = new StringWriter();
                File jsonFile = new File(
                        Constants.ResourcePath.GENERATED_IDENTITY_PATH + map.get(Constants.PID) + Constants.JSON_EXT);
                if (jsonFile.exists()) {
                    t.merge(context, writer);
                    String text = "";
                    try {
                        text = new String(Files.readAllBytes(jsonFile.toPath()));
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    try (FileWriter fw = new FileWriter(jsonFile)) {
                        int lastIndexOf = text.lastIndexOf("]");
                        String identityString = writer.toString();
                        identityString = StringUtils.removeStart(StringUtils.removeEnd(identityString, "]"), "[");
                        String finalStr = new StringBuilder(text).insert(text.length() - 2, "," + identityString)
                                .toString();
                        fw.write(finalStr);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    try (FileWriter fw = new FileWriter(jsonFile)) {

                        t.merge(context, writer);
                        fw.write(writer.toString()); //
                    } catch (IOException e) {
                        e.printStackTrace();
                    } //
                }
                index++;
            }
        }

    }

    /**
     * Method to format a List<String> with a given Delimiter to convert to single
     * String.
     * 
     * @param lookupList
     * @param delimiter
     * @return
     */
    private static String formatString(List<String> lookupList, String delimiter) {
        StringJoiner joiner = new StringJoiner(delimiter);
        for (String string : lookupList) {
            if (string == null) {
                joiner.add("");
            } else {
                joiner.add(string);
            }
        }
        return joiner.toString();
    }

    /**
     * Method to format a List<String> with a given Delimiter to convert to single
     * String. Adds second level formatting with another delimiter.
     * 
     * @param lookupList
     * @param delimeter
     * @param count
     * @param countDel
     * @return
     */
    private static String formatString(List<String> lookupList, String delimeter, int count, String countDel) {
        StringJoiner joiner = new StringJoiner(delimeter);
        StringJoiner cntjoiner = new StringJoiner(countDel);
        int ct = 0;
        int itr = 1;
        if (!CollectionUtils.isEmpty(lookupList)) {
            for (int i = 0; i <= lookupList.size(); i++) {
                if (i % (count) != 0) {
                    joiner.add(lookupList.get(i));
                } else if (i == 0 || i == count * itr + 1) {
                    joiner.add(lookupList.get(i));
                } else {
                    cntjoiner.add(joiner.toString());
                    itr++;
                    joiner = new StringJoiner(delimeter);
                    if (i < lookupList.size()) {
                        joiner.add(lookupList.get(i));
                    }
                }
            }
        }
        return cntjoiner.toString();

    }

    /**
     * Reads the DTDG Table from the given sheet in Excel File.
     * 
     * @param inputStream
     * @param sheetName
     * @return
     * @throws IOException
     */
    private static MultiValueMap<String, Map<String, String>> readTableFromExcel(FileInputStream inputStream,
            String sheetName) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet firstSheet = workbook.getSheet(sheetName);
        Iterator<Row> spliterator = firstSheet.iterator();
        List<XSSFTable> tables = firstSheet.getTables();
        MultiValueMap<String, Map<String, String>> rows = new LinkedMultiValueMap<>();

        for (XSSFTable t : tables) {
            System.out.println(t.getDisplayName());
            System.out.println(t.getName());
            System.out.println(t.getNumberOfMappedColumns());
            int startRow = t.getStartCellReference().getRow();
            int endRow = t.getEndCellReference().getRow();
            System.out.println("startRow = " + startRow);
            System.out.println("endRow = " + endRow);

            int startColumn = t.getStartCellReference().getCol();
            int endColumn = t.getEndCellReference().getCol();

            System.out.println("startColumn = " + startColumn);
            System.out.println("endColumn = " + endColumn);

            List<Pair<Integer, String>> consideredColumns = new ArrayList<Pair<Integer, String>>();
            for (int j = startColumn; j <= endColumn; j++) {
                XSSFCell cell = firstSheet.getRow(startRow).getCell(j);
                if (cell != null) {
                    String columnName = cell.getStringCellValue();
                    if (columnName != null) {
                        Integer cellColumn = j;
                        Pair<Integer, String> p = new ImmutablePair<Integer, String>(cellColumn, columnName);
                        consideredColumns.add(p);
                    }
                }
            }
            System.out.println(consideredColumns);
            for (int i = startRow + 1; i <= endRow; i++) {
                Map<String, String> tableCell = new TreeMap<>();
                for (Pair<Integer, String> pair : consideredColumns) {
                    XSSFCell cell = firstSheet.getRow(i).getCell(pair.getKey());
                    if (cell != null) {
                        String field = pair.getValue();
                        switch (cell.getCellType()) {
                        case STRING:
                            tableCell.put(field, cell.getStringCellValue());
                            break;
                        case NUMERIC:
                            tableCell.put(field, Double.toString(cell.getNumericCellValue()));
                            break;
                        default:
                            tableCell.put(field, cell.getRawValue());
                            break;

                        }
                    }
                }
                String sno = tableCell.remove("ACNo");
                rows.add(sno, tableCell);
            }
            System.out.println(rows);
        }
        return rows;
    }

}
