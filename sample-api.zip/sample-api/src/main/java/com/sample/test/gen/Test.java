package com.sample.test.tdg;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Test {

    public static void main(String[] args) {
        String jsonString = "{\r\n" + "    \"items\": [\r\n" + "        {\r\n"
                + "            \"s_d_id\": \"CID_CASES_1916610947\",\r\n"
                + "            \"created_datetime\": \"2015-07-17T05:30:00+05:30\",\r\n"
                + "            \"origin\": {\r\n" + "                \"case_id\": \"1916610947\",\r\n"
                + "                \"system\": {\r\n" + "                    \"reference_code\": \"CID\",\r\n"
                + "                    \"short_description\": \"CID\",\r\n"
                + "                    \"long_description\": \"CID\"\r\n" + "                }\r\n"
                + "            },\r\n" + "            \"category_3\": {\r\n"
                + "                \"reference_code\": \"APPLICATION\",\r\n"
                + "                \"short_description\": \"Application\",\r\n"
                + "                \"long_description\": \"Application\"\r\n" + "            }\r\n" + "        },\r\n"
                + "        {\r\n" + "            \"s_d_id\": \"ID_111111\",\r\n"
                + "            \"created_datetime\": \"2015-07-17T05:30:00+05:30\",\r\n"
                + "            \"origin\": {\r\n" + "                \"case_id\": \"1798101984\",\r\n"
                + "                \"system\": {\r\n" + "                    \"reference_code\": \"CID\",\r\n"
                + "                    \"short_description\": \"CID\",\r\n"
                + "                    \"long_description\": \"CID\"\r\n" + "                }\r\n"
                + "            },\r\n" + "            \"category_3\": {\r\n"
                + "                \"reference_code\": \"APPLICATION\",\r\n"
                + "                \"short_description\": \"Application\",\r\n"
                + "                \"long_description\": \"Application\"\r\n" + "            }\r\n" + "        }\r\n"
                + "    ]\r\n" + "}";
        Map<String, Object> retMap = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, Object>>() {
        }.getType());
        // System.out.println(retMap);
        
    }
}
