package com.sample.test.tdg;

import java.io.File;

public class Constants {

    public static final String TEMPLATE = "Template";
    public static final String IDENTITY_TYPE = "identity_type";
    public static final String INTERFACE_ID = "interface_id";
    public static final String CONTAINING_PID = "containing_pid";
    public static final String ID_MEDIA_IDENTIFIER = "id_media_identifier";
    public static final String PID = "pid";
    public static final String SOURCE = "source";

    public static final String JSON_EXT = ".json";

    static class Regex {
        public static final String B_SETS = "b_sets_";

    }

    static class TemplateType {
   
        public static final String IDENTITY = "Identity";
       
    }

    static class ResourcePath {
     
        public static final String IDENTITY_TEMPLATE_PATH = "/templates/identity.vm";
       
        public static final String FEATURE_TEMPLATE_PATH = "/templates/feature_template.vm";
        public static final String GENERATED_IDENTITY_PATH = "generated" + File.separator + "identities"
                + File.separator;
        public static final String GENERATED_FEATURE_PATH = "generated" + File.separator;

    }
}
