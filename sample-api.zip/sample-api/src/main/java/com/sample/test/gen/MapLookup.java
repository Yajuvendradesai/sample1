package com.sample.test.tdg;

import java.util.List;
import java.util.Map;

/**
 * Functional Interface for Lookup values on map based on regex.
 *
 */
@FunctionalInterface
public interface MapLookup {
    <V> List<V> lookup(String regularExpression, Map<String, V> map);
}